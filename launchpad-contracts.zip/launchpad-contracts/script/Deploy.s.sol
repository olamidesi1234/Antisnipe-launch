// SPDX-License-Identifier: MIT
pragma solidity ^0.8.24;

import "forge-std/Script.sol";
import "../contracts/LaunchpadFactory.sol";

/**
 * @notice Deploys LaunchpadFactory to whichever network is passed via --rpc-url.
 *
 * Usage (testnet):
 *   forge script script/Deploy.s.sol \
 *     --rpc-url robinhood_testnet \
 *     --broadcast \
 *     --private-key $PRIVATE_KEY
 *
 * Set TREASURY_ADDRESS in your .env, or it defaults to the deployer.
 */
contract Deploy is Script {
    // USDG on Robinhood Chain (same address on mainnet; confirm testnet address
    // separately since test-only tokens sometimes differ — check the explorer).
    address constant USDG_MAINNET = 0x5fc5360D0400a0Fd4f2af552ADD042D716F1d168;

    function run() external {
        uint256 deployerKey = vm.envUint("PRIVATE_KEY");
        address deployer = vm.addr(deployerKey);

        address treasury;
        try vm.envAddress("TREASURY_ADDRESS") returns (address t) {
            treasury = t;
        } catch {
            treasury = deployer;
        }

        address usdgAddr;
        try vm.envAddress("USDG_ADDRESS") returns (address u) {
            usdgAddr = u;
        } catch {
            usdgAddr = USDG_MAINNET;
            console.log("WARNING: USDG_ADDRESS not set in .env - using mainnet address.");
            console.log("Confirm the correct USDG address for your target network before broadcasting.");
        }

        uint256 launchFee;
        try vm.envUint("LAUNCH_FEE_USDG_WHOLE") returns (uint256 f) {
            launchFee = f * 1e18; // assumes 18 decimals; adjust if USDG uses fewer
        } catch {
            launchFee = 0; // free to launch by default, matching Pons/Pump.fun — revenue comes from trading fees instead
        }

        // Public address of the off-chain approval service's signing key (NOT its private key).
        // Required: without it, no one can buy during any token's protection window.
        address buySignerAddr = vm.envAddress("BUY_SIGNER_ADDRESS");

        vm.startBroadcast(deployerKey);
        LaunchpadFactory factory = new LaunchpadFactory(treasury, usdgAddr, launchFee, buySignerAddr);
        vm.stopBroadcast();

        console.log("LaunchpadFactory deployed at:", address(factory));
        console.log("Treasury set to:", treasury);
        console.log("USDG address used:", usdgAddr);
        console.log("Launch fee (USDG smallest units):", launchFee);
        console.log("Buy signer:", buySignerAddr);
        console.log("Deployer:", deployer);
    }
}
