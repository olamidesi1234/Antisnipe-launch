// SPDX-License-Identifier: MIT
pragma solidity ^0.8.24;

import "forge-std/Test.sol";
import "../contracts/LaunchpadFactory.sol";
import "../contracts/LaunchToken.sol";
import "../contracts/LaunchTypes.sol";
import "./MockUSDG.sol";

contract LaunchTokenTest is Test {
    LaunchpadFactory factory;
    LaunchToken token;
    MockUSDG usdg;

    address treasury;
    address creator;
    address alice;
    address bob;
    address sniper;

    address signer;
    uint256 signerPk;
    uint256 nonceCounter;

    uint256 constant SUPPLY = 1_000_000_000 ether;
    uint256 constant WINDOW = 900;             // 15 min
    uint256 constant MAX_WALLET_BPS = 100;     // 1%
    uint256 constant MAX_BUY_BPS = 25;         // 0.25%
    uint256 constant COOLDOWN = 5;             // seconds
    uint256 constant MAX_EARLY_BUYS = 1;
    uint256 constant ANTI_SNIPE_FEE_BPS = 800; // 8%
    uint256 constant NORMAL_FEE_BPS = 100;     // 1%

    function setUp() public {
        treasury = makeAddr("treasury");
        creator = makeAddr("creator");
        alice = makeAddr("alice");
        bob = makeAddr("bob");
        sniper = makeAddr("sniper");
        (signer, signerPk) = makeAddrAndKey("approvalSigner");

        usdg = new MockUSDG();
        factory = new LaunchpadFactory(treasury, address(usdg), 0, signer); // free launch

        usdg.mint(alice, 100_000 ether);
        usdg.mint(bob, 100_000 ether);
        usdg.mint(sniper, 100_000 ether);
        usdg.mint(creator, 100_000 ether);

        vm.prank(creator);
        token = LaunchToken(factory.launchToken(_params(0, 0)));
    }

    // ------------------------------------------------------------------ helpers
    function _params(uint256 launchDelay, uint256 firstBuy) internal pure returns (LaunchParams memory) {
        return LaunchParams({
            name: "Fair Coin",
            symbol: "FAIR",
            totalSupply: SUPPLY,
            launchDelaySeconds: launchDelay,
            protectionWindowSeconds: WINDOW,
            maxWalletBpsDuringWindow: MAX_WALLET_BPS,
            maxBuyBpsDuringWindow: MAX_BUY_BPS,
            buyCooldownSeconds: COOLDOWN,
            maxEarlyBuysPerWallet: MAX_EARLY_BUYS,
            antiSnipeFeeBps: ANTI_SNIPE_FEE_BPS,
            normalFeeBps: NORMAL_FEE_BPS,
            firstBuyUsdgAmount: firstBuy
        });
    }

    function _sigWithKey(uint256 pk, address tokenAddr, address buyer, uint256 expiry) internal pure returns (bytes memory) {
        bytes32 messageHash = keccak256(abi.encodePacked(tokenAddr, buyer, expiry));
        bytes32 digest = keccak256(abi.encodePacked("\x19Ethereum Signed Message:\n32", messageHash));
        (uint8 v, bytes32 r, bytes32 s) = vm.sign(pk, digest);
        return abi.encodePacked(r, s, v);
    }

    /// Approved buy: fresh expiry each time so every signature is unique.
    function _buy(address who, uint256 amount) internal {
        uint256 expiry = block.timestamp + 300 + (nonceCounter++);
        bytes memory sig = _sigWithKey(signerPk, address(token), who, expiry);
        vm.startPrank(who);
        usdg.approve(address(token), amount);
        token.buy(amount, expiry, sig);
        vm.stopPrank();
    }

    function _resolve(uint256 idx) internal {
        vm.roll(block.number + 4);
        vm.setBlockhash(block.number - 1, bytes32(uint256(12345)));
        uint256[] memory ids = new uint256[](1);
        ids[0] = idx;
        token.resolveQueue(ids);
    }

    // ------------------------------------------------------------------ 1. delayed trading
    function test_TradingBlockedBeforeLaunch() public {
        vm.prank(creator);
        LaunchToken dt = LaunchToken(factory.launchToken(_params(1 hours, 0)));

        uint256 expiry = block.timestamp + 300;
        bytes memory sig = _sigWithKey(signerPk, address(dt), alice, expiry);
        vm.startPrank(alice);
        usdg.approve(address(dt), 100 ether);
        vm.expectRevert(LaunchToken.TradingNotOpen.selector);
        dt.buy(100 ether, expiry, sig);
        vm.stopPrank();
    }

    // ------------------------------------------------------------------ 2. signature gate (the anti-multi-wallet layer)
    function test_BuyWithoutApprovalRevertsDuringWindow() public {
        vm.startPrank(alice);
        usdg.approve(address(token), 20 ether);
        vm.expectRevert(LaunchToken.InvalidApproval.selector);
        token.buy(20 ether, block.timestamp + 300, "");
        vm.stopPrank();
    }

    function test_ApprovalFromWrongKeyRejected() public {
        (, uint256 attackerPk) = makeAddrAndKey("attacker");
        uint256 expiry = block.timestamp + 300;
        bytes memory sig = _sigWithKey(attackerPk, address(token), alice, expiry);
        vm.startPrank(alice);
        usdg.approve(address(token), 20 ether);
        vm.expectRevert(LaunchToken.InvalidApproval.selector);
        token.buy(20 ether, expiry, sig);
        vm.stopPrank();
    }

    function test_ExpiredApprovalRejected() public {
        uint256 expiry = block.timestamp + 60;
        bytes memory sig = _sigWithKey(signerPk, address(token), alice, expiry);
        vm.warp(block.timestamp + 61);
        vm.startPrank(alice);
        usdg.approve(address(token), 20 ether);
        vm.expectRevert(LaunchToken.ApprovalExpired.selector);
        token.buy(20 ether, expiry, sig);
        vm.stopPrank();
    }

    function test_ApprovalIsBoundToTheWalletItWasIssuedFor() public {
        // Approval issued for alice cannot be used by sniper.
        uint256 expiry = block.timestamp + 300;
        bytes memory aliceSig = _sigWithKey(signerPk, address(token), alice, expiry);
        vm.startPrank(sniper);
        usdg.approve(address(token), 20 ether);
        vm.expectRevert(LaunchToken.InvalidApproval.selector);
        token.buy(20 ether, expiry, aliceSig);
        vm.stopPrank();
    }

    function test_ApprovalIsBoundToTheTokenItWasIssuedFor() public {
        vm.prank(creator);
        LaunchToken other = LaunchToken(factory.launchToken(_params(0, 0)));
        uint256 expiry = block.timestamp + 300;
        bytes memory sigForOther = _sigWithKey(signerPk, address(other), alice, expiry);
        vm.startPrank(alice);
        usdg.approve(address(token), 20 ether);
        vm.expectRevert(LaunchToken.InvalidApproval.selector);
        token.buy(20 ether, expiry, sigForOther); // used on the wrong token
        vm.stopPrank();
    }

    function test_ApprovalCannotBeReplayed() public {
        uint256 expiry = block.timestamp + 3000;
        bytes memory sig = _sigWithKey(signerPk, address(token), alice, expiry);
        vm.startPrank(alice);
        usdg.approve(address(token), 100 ether);
        token.buy(20 ether, expiry, sig);
        vm.warp(block.timestamp + COOLDOWN + 1);
        vm.expectRevert(LaunchToken.ApprovalAlreadyUsed.selector);
        token.buy(20 ether, expiry, sig);
        vm.stopPrank();
    }

    function test_MalleatedSignatureCannotBypassReplayProtection() public {
        uint256 expiry = block.timestamp + 3000;
        bytes32 messageHash = keccak256(abi.encodePacked(address(token), alice, expiry));
        bytes32 digest = keccak256(abi.encodePacked("\x19Ethereum Signed Message:\n32", messageHash));
        (uint8 v, bytes32 r, bytes32 s) = vm.sign(signerPk, digest);
        bytes memory sig = abi.encodePacked(r, s, v);

        // The mathematically-equivalent "twin" signature: s' = n - s, flipped v.
        uint256 n = 0xFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFEBAAEDCE6AF48A03BBFD25E8CD0364141;
        bytes32 sTwin = bytes32(n - uint256(s));
        uint8 vTwin = v == 27 ? 28 : 27;
        bytes memory twin = abi.encodePacked(r, sTwin, vTwin);

        vm.startPrank(alice);
        usdg.approve(address(token), 100 ether);
        token.buy(20 ether, expiry, sig);
        vm.warp(block.timestamp + COOLDOWN + 1);
        vm.expectRevert(); // rejected either as high-s (InvalidApproval) or as replay
        token.buy(20 ether, expiry, twin);
        vm.stopPrank();
    }

    function test_ApprovedSmallBuyQueues() public {
        _buy(alice, 20 ether);
        assertEq(token.pendingQueueLength(), 1);
    }

    function test_NoApprovalNeededAfterWindow() public {
        vm.warp(block.timestamp + WINDOW + 1);
        vm.startPrank(alice);
        usdg.approve(address(token), 500 ether);
        token.buy(500 ether, 0, ""); // no signature at all
        vm.stopPrank();
        assertGt(token.balanceOf(alice), 0);
    }

    function test_OwnerCanRotateSigner() public {
        (address newSigner, uint256 newPk) = makeAddrAndKey("newSigner");
        vm.prank(factory.owner());
        token.setBuySigner(newSigner);

        // Old key no longer works
        uint256 expiry = block.timestamp + 300;
        bytes memory oldSig = _sigWithKey(signerPk, address(token), alice, expiry);
        vm.startPrank(alice);
        usdg.approve(address(token), 40 ether);
        vm.expectRevert(LaunchToken.InvalidApproval.selector);
        token.buy(20 ether, expiry, oldSig);
        // New key works
        bytes memory newSig = _sigWithKey(newPk, address(token), alice, expiry + 1);
        token.buy(20 ether, expiry + 1, newSig);
        vm.stopPrank();
    }

    function test_OnlyOwnerCanRotateSigner() public {
        vm.prank(alice);
        vm.expectRevert(LaunchToken.NotOwner.selector);
        token.setBuySigner(alice);
    }

    // ------------------------------------------------------------------ 3. per-buy limits
    function test_MaxBuyPerTxEnforced() public {
        uint256 expiry = block.timestamp + 300;
        bytes memory sig = _sigWithKey(signerPk, address(token), alice, expiry);
        vm.startPrank(alice);
        usdg.approve(address(token), 20_000 ether);
        vm.expectRevert(LaunchToken.ExceedsMaxBuy.selector);
        token.buy(20_000 ether, expiry, sig);
        vm.stopPrank();
    }

    function test_CooldownBlocksRapidSecondBuy() public {
        _buy(alice, 20 ether);
        uint256 expiry = block.timestamp + 999;
        bytes memory sig = _sigWithKey(signerPk, address(token), alice, expiry);
        vm.startPrank(alice);
        usdg.approve(address(token), 20 ether);
        vm.expectRevert(LaunchToken.CooldownActive.selector);
        token.buy(20 ether, expiry, sig);
        vm.stopPrank();
    }

    function test_MaxEarlyBuysPerWalletEnforced() public {
        _buy(alice, 20 ether);
        vm.warp(block.timestamp + COOLDOWN + 1);
        uint256 expiry = block.timestamp + 999;
        bytes memory sig = _sigWithKey(signerPk, address(token), alice, expiry);
        vm.startPrank(alice);
        usdg.approve(address(token), 20 ether);
        vm.expectRevert(LaunchToken.TooManyEarlyBuys.selector);
        token.buy(20 ether, expiry, sig);
        vm.stopPrank();
    }

    // ------------------------------------------------------------------ 4. fees
    function test_FeeDecaysAfterWindow() public {
        assertEq(token.currentFeeBps(), ANTI_SNIPE_FEE_BPS);
        vm.warp(block.timestamp + WINDOW + 1);
        assertEq(token.currentFeeBps(), NORMAL_FEE_BPS);
    }

    function test_TradingFeeSplits70CreatorAnd30Protocol() public {
        vm.warp(block.timestamp + WINDOW + 1);
        uint256 creatorBefore = usdg.balanceOf(creator);
        uint256 treasuryBefore = usdg.balanceOf(treasury);

        vm.startPrank(alice);
        usdg.approve(address(token), 1000 ether);
        token.buy(1000 ether, 0, ""); // 1% fee = 10 USDG
        vm.stopPrank();

        assertEq(usdg.balanceOf(creator) - creatorBefore, 7 ether);   // 70% of 10
        assertEq(usdg.balanceOf(treasury) - treasuryBefore, 3 ether); // 30% of 10
    }

    // ------------------------------------------------------------------ 5. no insider buys
    function test_CreatorCannotBuyDuringWindow() public {
        uint256 expiry = block.timestamp + 300;
        bytes memory sig = _sigWithKey(signerPk, address(token), creator, expiry); // even WITH a valid approval
        vm.startPrank(creator);
        usdg.approve(address(token), 20 ether);
        vm.expectRevert(LaunchToken.InsiderBuyBlocked.selector);
        token.buy(20 ether, expiry, sig);
        vm.stopPrank();
    }

    function test_CreatorCanBuyAfterWindow() public {
        vm.warp(block.timestamp + WINDOW + 1);
        vm.startPrank(creator);
        usdg.approve(address(token), 20 ether);
        token.buy(20 ether, 0, "");
        vm.stopPrank();
    }

    // ------------------------------------------------------------------ 6. blocklist
    function test_OnlyProtocolOwnerCanBlock() public {
        vm.prank(alice);
        vm.expectRevert(LaunchToken.NotOwner.selector);
        token.setWalletBlocked(sniper, true);
    }

    function test_ProtocolOwnerBlocksWallet() public {
        vm.prank(factory.owner());
        token.setWalletBlocked(sniper, true);

        uint256 expiry = block.timestamp + 300;
        bytes memory sig = _sigWithKey(signerPk, address(token), sniper, expiry);
        vm.startPrank(sniper);
        usdg.approve(address(token), 20 ether);
        vm.expectRevert(LaunchToken.WalletIsBlocked.selector);
        token.buy(20 ether, expiry, sig);
        vm.stopPrank();
    }

    // ------------------------------------------------------------------ 7. commit-reveal queue
    function test_QueuedBuyCannotResolveEarly() public {
        _buy(alice, 20 ether);
        uint256[] memory idx = new uint256[](1);
        idx[0] = 0;
        vm.expectRevert(LaunchToken.TooEarlyToReveal.selector);
        token.resolveQueue(idx);
    }

    function test_QueuedBuyResolvesAfterRevealBlocks() public {
        _buy(alice, 20 ether);
        _resolve(0);
        assertGt(token.balanceOf(alice), 0);
    }

    function test_MultipleQueuedBuyersBothFilled() public {
        _buy(alice, 20 ether);
        _buy(bob, 20 ether);
        vm.roll(block.number + 4);
        vm.setBlockhash(block.number - 1, bytes32(uint256(999)));
        uint256[] memory idx = new uint256[](2);
        idx[0] = 0; idx[1] = 1;
        token.resolveQueue(idx);
        assertGt(token.balanceOf(alice), 0);
        assertGt(token.balanceOf(bob), 0);
    }

    // ------------------------------------------------------------------ 8. normal trading after the window
    function test_NormalBuySellAfterWindow() public {
        vm.warp(block.timestamp + WINDOW + 1);
        vm.startPrank(alice);
        usdg.approve(address(token), 500 ether);
        token.buy(500 ether, 0, "");
        uint256 bal = token.balanceOf(alice);
        assertGt(bal, 0);
        uint256 usdgBefore = usdg.balanceOf(alice);
        token.sell(bal / 2);
        vm.stopPrank();
        assertLt(token.balanceOf(alice), bal);
        assertGt(usdg.balanceOf(alice), usdgBefore);
    }

    // ------------------------------------------------------------------ 9. launch fee (defaults to free)
    function test_LaunchIsFreeByDefault() public view {
        assertEq(factory.launchFeeUsdg(), 0);
    }

    function test_LaunchFeeChargedWhenSet() public {
        LaunchpadFactory feeFactory = new LaunchpadFactory(treasury, address(usdg), 20 ether, signer);
        uint256 before_ = usdg.balanceOf(treasury);
        vm.startPrank(creator);
        usdg.approve(address(feeFactory), 20 ether);
        feeFactory.launchToken(_params(0, 0));
        vm.stopPrank();
        assertEq(usdg.balanceOf(treasury), before_ + 20 ether);
    }

    function test_LaunchFailsWithoutFeeApproval() public {
        LaunchpadFactory feeFactory = new LaunchpadFactory(treasury, address(usdg), 20 ether, signer);
        vm.prank(creator);
        vm.expectRevert();
        feeFactory.launchToken(_params(0, 0));
    }

    // ------------------------------------------------------------------ 10. creator first buy
    function test_CreatorFirstBuyHappensAtomicallyAtLaunch() public {
        vm.startPrank(creator);
        usdg.approve(address(factory), 50 ether);
        LaunchToken t = LaunchToken(factory.launchToken(_params(0, 50 ether)));
        vm.stopPrank();

        assertGt(t.balanceOf(creator), 0);
        assertTrue(t.creatorFirstBuyUsed());
    }

    function test_CreatorFirstBuyCannotExceedWalletCap() public {
        // 100 USDG at an 8% fee buys ~10.9M tokens, over the 1% (10M) wallet cap.
        vm.startPrank(creator);
        usdg.approve(address(factory), 100 ether);
        LaunchParams memory p = _params(0, 100 ether);
        vm.expectRevert(bytes("exceeds wallet cap"));
        factory.launchToken(p);
        vm.stopPrank();
    }

    function test_FirstBuyCannotBeCalledDirectlyByCreator() public {
        vm.prank(creator);
        vm.expectRevert(LaunchToken.OnlyFactory.selector);
        token.creatorFirstBuy(10 ether);
    }

    function test_NoFirstBuyMeansCreatorHoldsNothing() public view {
        assertEq(token.balanceOf(creator), 0);
        assertFalse(token.creatorFirstBuyUsed());
    }
}
