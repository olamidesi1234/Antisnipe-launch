// SPDX-License-Identifier: MIT
pragma solidity ^0.8.24;

import "./IERC20.sol";
import "./LaunchTypes.sol";

/**
 * @title LaunchToken
 * @notice Fixed-supply ERC-20 with a bonding curve priced in USDG (Robinhood Chain's
 *         native stablecoin, not ETH), an anti-snipe launch window, wallet blocklist,
 *         and commit-reveal fair allocation for buys placed during the window.
 *
 * PROTECTION WINDOW MECHANICS (from launchTime to launchTime + protectionWindowSeconds):
 *   1. Every wallet is capped at `maxWalletBpsDuringWindow` of total supply held.
 *   2. Every single buy is capped at `maxBuyBpsDuringWindow` of total supply.
 *   3. A wallet must wait `buyCooldownSeconds` between buys.
 *   4. A wallet gets at most `maxEarlyBuysPerWallet` buys during the window.
 *   5. Creator and protocol-owner wallets cannot buy at all (no insider buys).
 *   6. Trades pay `antiSnipeFeeBps` instead of `normalFeeBps`.
 *   7. Buys are queued (commit) and settled later via `resolveQueue`, using a
 *      randomized partial-fill factor derived from a future blockhash the buyer
 *      could not have known when queuing — not first-come-first-served.
 *
 * QUOTE CURRENCY: all amounts (reserve, buys, sells, fees) are denominated in USDG,
 * an ERC-20 stablecoin. Buyers must `usdg.approve(token, amount)` before calling buy().
 *
 * NOTE ON RANDOMNESS: blockhash-based seed is buyer-proof (buyer can't predict it when
 * queuing) but not fully validator-proof. Swap `_seed()` for Chainlink VRF before
 * mainnet deployment with real funds.
 *
 * UNAUDITED. Do not deploy with real funds before a professional security audit.
 */
contract LaunchToken is IERC20 {
    string public name;
    string public symbol;
    uint8 public constant override decimals = 18;
    uint256 public override totalSupply;

    mapping(address => uint256) private _balances;
    mapping(address => mapping(address => uint256)) private _allowances;

    address public creator;
    address public protocolOwner;
    address public protocolTreasury;
    address public immutable launchpadFactory;
    address public buySigner; // off-chain risk-check service's key; rotatable in case of key rotation
    IERC20 public immutable usdg;
    uint256 public immutable usdgUnit; // 10 ** usdg.decimals(), scales virtual liquidity correctly

    uint256 public immutable launchTime;
    uint256 public immutable protectionWindowSeconds;
    uint256 public immutable maxWalletBpsDuringWindow;
    uint256 public immutable maxBuyBpsDuringWindow;
    uint256 public immutable buyCooldownSeconds;
    uint256 public immutable maxEarlyBuysPerWallet;
    uint256 public immutable antiSnipeFeeBps;
    uint256 public immutable normalFeeBps;

    // Graduation target expressed in whole USDG units (e.g. 30_000 = $30,000 raised).
    uint256 public constant GRADUATION_USDG_TARGET_WHOLE = 30_000;
    uint256 public reserveBalance; // USDG held by the curve
    bool public graduated;

    mapping(address => bool) public isBlocked;
    mapping(address => uint256) public lastBuyTimestamp;
    mapping(address => uint256) public windowBuyCount;

    struct QueuedBuy {
        address buyer;
        uint256 usdgAmount;
        uint256 queueBlock;
        bool resolved;
    }

    QueuedBuy[] public queue;
    mapping(address => uint256) public queuedUsdgByWallet;

    event Queued(address indexed buyer, uint256 usdgAmount, uint256 indexed queueIndex, uint256 revealBlock);
    event Resolved(uint256 indexed queueIndex, address indexed buyer, uint256 tokensOut, bool filled);
    event WalletBlocked(address indexed wallet, bool blocked);
    event Graduated(uint256 reserveBalance);
    event Sell(address indexed seller, uint256 tokenAmount, uint256 usdgOut);

    error NotOwner();
    error TradingNotOpen();
    error WalletIsBlocked();
    error InsiderBuyBlocked();
    error ExceedsWalletCap();
    error ExceedsMaxBuy();
    error CooldownActive();
    error TooManyEarlyBuys();
    error AlreadyGraduated();
    error TooEarlyToReveal();
    error AlreadyResolved();
    error InsufficientBalance();

    uint256 public constant CREATOR_FEE_SHARE_BPS = 7000; // 70% to creator, 30% to protocol — matches Pons's model

    function _splitFee(uint256 fee) internal {
        if (fee == 0) return;
        uint256 creatorCut = (fee * CREATOR_FEE_SHARE_BPS) / 10_000;
        uint256 protocolCut = fee - creatorCut;
        if (creatorCut > 0) {
            bool s1 = usdg.transfer(creator, creatorCut);
            require(s1, "creator fee transfer failed");
        }
        if (protocolCut > 0) {
            bool s2 = usdg.transfer(protocolTreasury, protocolCut);
            require(s2, "protocol fee transfer failed");
        }
    }

    modifier onlyProtocolOwner() {
        if (msg.sender != protocolOwner) revert NotOwner();
        _;
    }

    constructor(LaunchConfig memory cfg) {
        name = cfg.p.name;
        symbol = cfg.p.symbol;
        totalSupply = cfg.p.totalSupply;
        creator = cfg.creator;
        protocolOwner = cfg.protocolOwner;
        protocolTreasury = cfg.protocolTreasury;
        launchpadFactory = cfg.launchpadFactory;
        buySigner = cfg.buySigner;
        usdg = IERC20(cfg.usdg);
        usdgUnit = 10 ** IERC20(cfg.usdg).decimals();

        launchTime = cfg.launchTime;
        protectionWindowSeconds = cfg.p.protectionWindowSeconds;
        maxWalletBpsDuringWindow = cfg.p.maxWalletBpsDuringWindow;
        maxBuyBpsDuringWindow = cfg.p.maxBuyBpsDuringWindow;
        buyCooldownSeconds = cfg.p.buyCooldownSeconds;
        maxEarlyBuysPerWallet = cfg.p.maxEarlyBuysPerWallet;
        antiSnipeFeeBps = cfg.p.antiSnipeFeeBps;
        normalFeeBps = cfg.p.normalFeeBps;

        _balances[address(this)] = cfg.p.totalSupply;
        emit Transfer(address(0), address(this), cfg.p.totalSupply);
    }

    // ------------------------------------------------------------------
    // Admin: wallet blocklist — blocks the WALLET, independent of bot-or-not.
    // ------------------------------------------------------------------
    function setWalletBlocked(address wallet, bool blocked) external onlyProtocolOwner {
        isBlocked[wallet] = blocked;
        emit WalletBlocked(wallet, blocked);
    }

    /// @notice Rotate the off-chain approval service's signing key, in case it's ever compromised.
    function setBuySigner(address newSigner) external onlyProtocolOwner {
        buySigner = newSigner;
    }

    function setWalletsBlockedBatch(address[] calldata wallets, bool blocked) external onlyProtocolOwner {
        for (uint256 i = 0; i < wallets.length; i++) {
            isBlocked[wallets[i]] = blocked;
            emit WalletBlocked(wallets[i], blocked);
        }
    }

    // ------------------------------------------------------------------
    // View helpers
    // ------------------------------------------------------------------
    function inProtectionWindow() public view returns (bool) {
        return block.timestamp >= launchTime && block.timestamp < launchTime + protectionWindowSeconds;
    }

    function tradingOpen() public view returns (bool) {
        return block.timestamp >= launchTime;
    }

    function currentFeeBps() public view returns (uint256) {
        return inProtectionWindow() ? antiSnipeFeeBps : normalFeeBps;
    }

    function graduationTarget() public view returns (uint256) {
        return GRADUATION_USDG_TARGET_WHOLE * usdgUnit;
    }

    /// @dev Constant-product-style curve. Virtual floor scales with USDG's own decimals
    ///      so the curve behaves the same regardless of whether USDG uses 6 or 18 decimals.
    function quoteBuy(uint256 usdgIn) public view returns (uint256 tokensOut) {
        uint256 virtualReserve = reserveBalance + (10_000 * usdgUnit); // virtual liquidity floor
        uint256 virtualSupply = _balances[address(this)] + (totalSupply / 5);
        uint256 k = virtualReserve * virtualSupply;
        uint256 newReserve = virtualReserve + usdgIn;
        uint256 newSupplySide = k / newReserve;
        tokensOut = virtualSupply - newSupplySide;
    }

    // ------------------------------------------------------------------
    // Buying — caller must usdg.approve(address(this), usdgAmount) first.
    // ------------------------------------------------------------------
    error OnlyFactory();
    error FirstBuyAlreadyUsed();
    error PublicBuysAlreadyStarted();
    error ApprovalExpired();
    error ApprovalAlreadyUsed();
    error InvalidApproval();

    bool public creatorFirstBuyUsed;
    mapping(bytes32 => bool) public usedApprovals; // keyed by message hash, see _requireValidApproval

    /**
     * @notice Every buy during the protection window must carry a fresh signature from
     *         buySigner (the off-chain Sniper Risk Score service), approving THIS wallet
     *         for THIS token before THIS expiry. This is what closes the gap plain on-chain
     *         rules can't: the off-chain service can check wallet age, funding-source
     *         clustering, and cross-wallet patterns invisible to the contract itself, then
     *         simply refuse to sign for anything it flags as risky.
     * @dev Message format: keccak256(tokenAddress, buyerWallet, expiryTimestamp), signed
     *      with the standard "personal_sign" prefix (matches ethers.js signMessage()).
     *      Each signature can only be consumed once — replaying an old approval reverts.
     */
    function _requireValidApproval(address buyer, uint256 expiry, bytes memory signature) internal {
        if (block.timestamp > expiry) revert ApprovalExpired();

        bytes32 messageHash = keccak256(abi.encodePacked(address(this), buyer, expiry));
        bytes32 signedHash = keccak256(abi.encodePacked("\x19Ethereum Signed Message:\n32", messageHash));

        // Replay protection is keyed on the MESSAGE, not the signature: ECDSA signatures are
        // malleable (a valid signature can be transformed into a different-looking valid one),
        // so keying on the signature bytes would let one approval be spent twice.
        if (usedApprovals[messageHash]) revert ApprovalAlreadyUsed();
        usedApprovals[messageHash] = true;

        address recovered = _recoverSigner(signedHash, signature);
        if (recovered != buySigner || buySigner == address(0)) revert InvalidApproval();
    }

    function _recoverSigner(bytes32 hash, bytes memory signature) internal pure returns (address) {
        if (signature.length != 65) return address(0);
        bytes32 r; bytes32 s; uint8 v;
        assembly {
            r := mload(add(signature, 32))
            s := mload(add(signature, 64))
            v := byte(0, mload(add(signature, 96)))
        }
        if (v < 27) v += 27;
        // Reject the "high-s" malleable form of a signature (EIP-2 style hygiene).
        if (uint256(s) > 0x7FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF5D576E7357A4501DDFE92F46681B20A0) return address(0);
        if (v != 27 && v != 28) return address(0);
        return ecrecover(hash, v, r, s);
    }

    /**
     * @notice The ONE exception to "no insider buys": lets the creator buy a modest,
     *         pre-declared amount atomically at launch, before any public buy can happen.
     *         Only callable by the factory itself, in the same transaction that deploys
     *         this token — never as a separate call later, and never more than once.
     *         Still subject to the same wallet cap everyone else gets during the window,
     *         so it cannot be used to quietly grab a large share of supply.
     */
    function creatorFirstBuy(uint256 usdgAmount) external returns (uint256 tokensOut) {
        if (msg.sender != launchpadFactory) revert OnlyFactory();
        if (creatorFirstBuyUsed) revert FirstBuyAlreadyUsed();
        if (_balances[address(this)] != totalSupply) revert PublicBuysAlreadyStarted();
        creatorFirstBuyUsed = true;

        bool ok = usdg.transferFrom(msg.sender, address(this), usdgAmount);
        require(ok, "USDG transferFrom failed");

        uint256 feeBps = currentFeeBps();
        uint256 fee = (usdgAmount * feeBps) / 10_000;
        uint256 netUsdg = usdgAmount - fee;
        _splitFee(fee);

        tokensOut = quoteBuy(netUsdg);
        uint256 walletCap = (totalSupply * maxWalletBpsDuringWindow) / 10_000;
        require(tokensOut <= walletCap, "exceeds wallet cap");

        reserveBalance += netUsdg;
        _balances[address(this)] -= tokensOut;
        _balances[creator] += tokensOut;
        emit Transfer(address(this), creator, tokensOut);
        _checkGraduation();
    }

    /// @param approvalExpiry Unix timestamp the off-chain approval is valid until (ignored outside the window)
    /// @param approvalSignature Signature from buySigner approving this wallet (ignored outside the window)
    function buy(uint256 usdgAmount, uint256 approvalExpiry, bytes calldata approvalSignature) external {
        if (isBlocked[msg.sender]) revert WalletIsBlocked();
        if (!tradingOpen()) revert TradingNotOpen();
        if (graduated) revert AlreadyGraduated();
        if (usdgAmount == 0) revert InsufficientBalance();

        if (inProtectionWindow()) {
            if (msg.sender == creator || msg.sender == protocolOwner) revert InsiderBuyBlocked();
            // Off-chain risk check gate: no valid signature, no buy during the window.
            _requireValidApproval(msg.sender, approvalExpiry, approvalSignature);
        }

        bool ok = usdg.transferFrom(msg.sender, address(this), usdgAmount);
        require(ok, "USDG transferFrom failed");

        if (inProtectionWindow()) {
            if (block.timestamp < lastBuyTimestamp[msg.sender] + buyCooldownSeconds) revert CooldownActive();
            if (windowBuyCount[msg.sender] >= maxEarlyBuysPerWallet) revert TooManyEarlyBuys();

            uint256 fee = (usdgAmount * antiSnipeFeeBps) / 10_000;
            uint256 netUsdg = usdgAmount - fee;
            _splitFee(fee);

            uint256 maxBuyCap = (totalSupply * maxBuyBpsDuringWindow) / 10_000;
            uint256 projectedTokens = quoteBuy(netUsdg);
            if (projectedTokens > maxBuyCap) revert ExceedsMaxBuy();

            uint256 walletCap = (totalSupply * maxWalletBpsDuringWindow) / 10_000;
            uint256 projectedBalance = _balances[msg.sender] + _pendingTokensFor(msg.sender) + projectedTokens;
            if (projectedBalance > walletCap) revert ExceedsWalletCap();

            lastBuyTimestamp[msg.sender] = block.timestamp;
            windowBuyCount[msg.sender] += 1;

            queue.push(QueuedBuy({ buyer: msg.sender, usdgAmount: netUsdg, queueBlock: block.number, resolved: false }));
            queuedUsdgByWallet[msg.sender] += netUsdg;

            emit Queued(msg.sender, netUsdg, queue.length - 1, block.number + 3);
        } else {
            _executeBuy(msg.sender, usdgAmount, normalFeeBps);
        }
    }

    /**
     * @notice Resolve queued buys once their reveal block (queueBlock + 3) exists.
     *         Anyone can call this (keeper-friendly). Fill order/size is randomized
     *         using the blockhash of each buy's reveal block.
     */
    function resolveQueue(uint256[] calldata indices) external {
        for (uint256 i = 0; i < indices.length; i++) {
            uint256 idx = indices[i];
            QueuedBuy storage q = queue[idx];
            if (q.resolved) revert AlreadyResolved();
            if (block.number <= q.queueBlock + 3) revert TooEarlyToReveal(); // need block+3 to be mined so its hash exists

            q.resolved = true;
            queuedUsdgByWallet[q.buyer] -= q.usdgAmount;

            if (graduated || isBlocked[q.buyer]) {
                bool s = usdg.transfer(q.buyer, q.usdgAmount);
                require(s, "refund failed");
                emit Resolved(idx, q.buyer, 0, false);
                continue;
            }

            uint256 seed = _seed(q.queueBlock);
            uint256 fillBps = 8_500 + (seed % 1_501); // randomized 85.00% - 100.00% fill
            uint256 fillUsdg = (q.usdgAmount * fillBps) / 10_000;
            uint256 refundUsdg = q.usdgAmount - fillUsdg;

            uint256 tokensOut = quoteBuy(fillUsdg);
            uint256 walletCap = (totalSupply * maxWalletBpsDuringWindow) / 10_000;
            if (_balances[q.buyer] + tokensOut > walletCap) {
                tokensOut = walletCap > _balances[q.buyer] ? walletCap - _balances[q.buyer] : 0;
                uint256 usedUsdg = tokensOut == 0 ? 0 : _usdgForTokens(tokensOut);
                refundUsdg = q.usdgAmount - usedUsdg;
                fillUsdg = usedUsdg;
            }

            reserveBalance += fillUsdg;
            _balances[address(this)] -= tokensOut;
            _balances[q.buyer] += tokensOut;
            emit Transfer(address(this), q.buyer, tokensOut);

            if (refundUsdg > 0) {
                bool s2 = usdg.transfer(q.buyer, refundUsdg);
                require(s2, "refund failed");
            }

            emit Resolved(idx, q.buyer, tokensOut, true);
            _checkGraduation();
        }
    }

    function pendingQueueLength() external view returns (uint256) {
        return queue.length;
    }

    function _pendingTokensFor(address wallet) internal view returns (uint256) {
        uint256 pendingUsdg = queuedUsdgByWallet[wallet];
        if (pendingUsdg == 0) return 0;
        return quoteBuy(pendingUsdg);
    }

    function _executeBuy(address buyer, uint256 usdgIn, uint256 feeBps) internal {
        uint256 fee = (usdgIn * feeBps) / 10_000;
        uint256 netUsdg = usdgIn - fee;
        _splitFee(fee);
        uint256 tokensOut = quoteBuy(netUsdg);
        reserveBalance += netUsdg;
        _balances[address(this)] -= tokensOut;
        _balances[buyer] += tokensOut;
        emit Transfer(address(this), buyer, tokensOut);
        _checkGraduation();
    }

    function _usdgForTokens(uint256 tokensOut) internal view returns (uint256) {
        uint256 virtualReserve = reserveBalance + (10_000 * usdgUnit);
        uint256 virtualSupply = _balances[address(this)] + (totalSupply / 5);
        uint256 k = virtualReserve * virtualSupply;
        uint256 newSupplySide = virtualSupply - tokensOut;
        uint256 newReserve = k / newSupplySide;
        return newReserve - virtualReserve;
    }

    function _seed(uint256 queueBlock) internal view returns (uint256) {
        // Hash of block (queueBlock + 3): did not exist when the buyer committed, and is
        // guaranteed to exist now because resolveQueue requires block.number > queueBlock + 3.
        bytes32 h = blockhash(queueBlock + 3);
        // blockhash() returns 0 for blocks older than 256; fall back to the latest available hash.
        if (h == bytes32(0)) h = blockhash(block.number - 1);
        return uint256(keccak256(abi.encodePacked(h, queueBlock)));
    }

    function _checkGraduation() internal {
        if (!graduated && reserveBalance >= graduationTarget()) {
            graduated = true;
            emit Graduated(reserveBalance);
            // Liquidity-lock / DEX migration hook: deposit reserveBalance (USDG) +
            // remaining curve-held tokens into a locked LP position on the target DEX.
        }
    }

    // ------------------------------------------------------------------
    // Selling — pays out USDG, not ETH.
    // ------------------------------------------------------------------
    function sell(uint256 tokenAmount) external {
        if (isBlocked[msg.sender]) revert WalletIsBlocked();
        if (!tradingOpen()) revert TradingNotOpen();
        if (_balances[msg.sender] < tokenAmount) revert InsufficientBalance();

        uint256 virtualReserve = reserveBalance + (10_000 * usdgUnit);
        uint256 virtualSupply = _balances[address(this)] + (totalSupply / 5);
        uint256 k = virtualReserve * virtualSupply;
        uint256 newSupplySide = virtualSupply + tokenAmount;
        uint256 newReserve = k / newSupplySide;
        uint256 usdgOutGross = virtualReserve - newReserve;

        uint256 fee = (usdgOutGross * currentFeeBps()) / 10_000;
        uint256 usdgOutNet = usdgOutGross - fee;

        _balances[msg.sender] -= tokenAmount;
        _balances[address(this)] += tokenAmount;
        emit Transfer(msg.sender, address(this), tokenAmount);

        reserveBalance -= usdgOutGross;
        _splitFee(fee);
        bool s2 = usdg.transfer(msg.sender, usdgOutNet);
        require(s2, "payout failed");

        emit Sell(msg.sender, tokenAmount, usdgOutNet);
    }

    // ------------------------------------------------------------------
    // Standard ERC-20 (transfers respect the blocklist)
    // ------------------------------------------------------------------
    function balanceOf(address account) external view returns (uint256) { return _balances[account]; }
    function allowance(address owner_, address spender) external view returns (uint256) { return _allowances[owner_][spender]; }

    function approve(address spender, uint256 amount) external returns (bool) {
        _allowances[msg.sender][spender] = amount;
        emit Approval(msg.sender, spender, amount);
        return true;
    }

    function transfer(address to, uint256 amount) external returns (bool) {
        _transfer(msg.sender, to, amount);
        return true;
    }

    function transferFrom(address from, address to, uint256 amount) external returns (bool) {
        uint256 allowed = _allowances[from][msg.sender];
        require(allowed >= amount, "allowance too low");
        _allowances[from][msg.sender] = allowed - amount;
        _transfer(from, to, amount);
        return true;
    }

    function _transfer(address from, address to, uint256 amount) internal {
        if (isBlocked[from] || isBlocked[to]) revert WalletIsBlocked();
        require(_balances[from] >= amount, "balance too low");
        _balances[from] -= amount;
        _balances[to] += amount;
        emit Transfer(from, to, amount);
    }
}
