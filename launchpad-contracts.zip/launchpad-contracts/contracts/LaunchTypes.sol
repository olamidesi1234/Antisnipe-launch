// SPDX-License-Identifier: MIT
pragma solidity ^0.8.24;

/// @notice Creator-facing launch parameters (passed from the frontend / factory call).
struct LaunchParams {
    string name;
    string symbol;
    uint256 totalSupply;
    uint256 launchDelaySeconds;
    uint256 protectionWindowSeconds;
    uint256 maxWalletBpsDuringWindow;   // e.g. 100 = 1% of supply, max held per wallet
    uint256 maxBuyBpsDuringWindow;      // e.g. 25 = 0.25% of supply, max per single buy
    uint256 buyCooldownSeconds;         // e.g. 5, min seconds between buys from same wallet
    uint256 maxEarlyBuysPerWallet;      // e.g. 1, max number of buys per wallet during window
    uint256 antiSnipeFeeBps;
    uint256 normalFeeBps;
    uint256 firstBuyUsdgAmount;         // optional: creator buys this amount atomically at launch,
                                         // before anyone else can — 0 means no first buy (default,
                                         // matches the no-insider-buy design). Still capped by
                                         // maxWalletBpsDuringWindow like any other holding.
}

/// @notice Full config passed into LaunchToken's constructor, adding protocol-level fields
///         the factory fills in on top of the creator's LaunchParams.
struct LaunchConfig {
    LaunchParams p;
    address creator;
    address protocolOwner;
    address protocolTreasury;
    address usdg;
    address launchpadFactory; // only this address may call creatorFirstBuy, keeping the bootstrap atomic
    address buySigner;        // off-chain risk-check service's signing key; buys during the
                               // protection window require a valid signature from this address
    uint256 launchTime;
}
