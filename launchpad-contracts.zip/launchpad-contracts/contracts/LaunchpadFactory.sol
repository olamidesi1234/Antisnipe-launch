// SPDX-License-Identifier: MIT
pragma solidity ^0.8.24;

import "./LaunchToken.sol";
import "./LaunchTypes.sol";
import "./IERC20.sol";

/**
 * @title LaunchpadFactory
 * @notice No-code deployer for fair-launch, anti-snipe tokens on Robinhood Chain,
 *         priced in USDG rather than ETH.
 *
 * UNAUDITED. Do not deploy to mainnet with real funds until independently audited.
 */
contract LaunchpadFactory {
    address public protocolTreasury;
    address public owner;
    address public immutable usdg;

    /// @notice Flat fee (in USDG's smallest unit) charged to the creator on every
    ///         deploy, paid straight to protocolTreasury. Set in the constructor,
    ///         e.g. 20 * 10**usdgDecimals for a flat $20 launch fee.
    uint256 public launchFeeUsdg;

    /// @notice Signing key of the off-chain risk-check service. Every new token is created
    ///         with this as its buySigner; buys during each token's protection window
    ///         require a signature from it.
    address public buySigner;

    event TokenLaunched(
        address indexed token,
        address indexed creator,
        string name,
        string symbol,
        uint256 launchTime,
        uint256 protectionWindowSeconds
    );
    event LaunchFeeUpdated(uint256 newFeeUsdg);

    error NotOwner();
    error ZeroAddress();
    error LaunchFeePaymentFailed();

    modifier onlyOwner() {
        if (msg.sender != owner) revert NotOwner();
        _;
    }

    constructor(address _protocolTreasury, address _usdg, uint256 _launchFeeUsdg, address _buySigner) {
        if (_protocolTreasury == address(0) || _usdg == address(0)) revert ZeroAddress();
        protocolTreasury = _protocolTreasury;
        usdg = _usdg;
        owner = msg.sender;
        launchFeeUsdg = _launchFeeUsdg;
        buySigner = _buySigner;
    }

    /**
     * @notice Deploy a new anti-snipe launch token. See LaunchTypes.sol for field meanings.
     * @dev Creator must usdg.approve(address(this), launchFeeUsdg) before calling, if
     *      launchFeeUsdg > 0. The fee is pulled BEFORE the token deploys, so a failed
     *      payment reverts the whole launch — no free launches, no stuck partial state.
     */
    function launchToken(LaunchParams calldata p) external returns (address tokenAddr) {
        if (launchFeeUsdg > 0) {
            bool ok = IERC20(usdg).transferFrom(msg.sender, protocolTreasury, launchFeeUsdg);
            if (!ok) revert LaunchFeePaymentFailed();
        }

        LaunchConfig memory cfg = LaunchConfig({
            p: p,
            creator: msg.sender,
            protocolOwner: owner,
            protocolTreasury: protocolTreasury,
            usdg: usdg,
            launchpadFactory: address(this),
            buySigner: buySigner,
            launchTime: block.timestamp + p.launchDelaySeconds
        });

        LaunchToken token = new LaunchToken(cfg);
        tokenAddr = address(token);

        if (p.firstBuyUsdgAmount > 0) {
            bool ok2 = IERC20(usdg).transferFrom(msg.sender, address(this), p.firstBuyUsdgAmount);
            if (!ok2) revert LaunchFeePaymentFailed();
            IERC20(usdg).approve(tokenAddr, p.firstBuyUsdgAmount);
            token.creatorFirstBuy(p.firstBuyUsdgAmount);
        }

        emit TokenLaunched(tokenAddr, msg.sender, p.name, p.symbol, cfg.launchTime, p.protectionWindowSeconds);
    }

    /// @notice Rotate the signing key used for FUTURE tokens (existing tokens each have their own setBuySigner).
    function setBuySigner(address newSigner) external onlyOwner {
        buySigner = newSigner;
    }

    function setLaunchFee(uint256 newFeeUsdg) external onlyOwner {
        launchFeeUsdg = newFeeUsdg;
        emit LaunchFeeUpdated(newFeeUsdg);
    }

    function setProtocolTreasury(address _treasury) external onlyOwner {
        if (_treasury == address(0)) revert ZeroAddress();
        protocolTreasury = _treasury;
    }

    function transferOwnership(address newOwner) external onlyOwner {
        if (newOwner == address(0)) revert ZeroAddress();
        owner = newOwner;
    }
}
