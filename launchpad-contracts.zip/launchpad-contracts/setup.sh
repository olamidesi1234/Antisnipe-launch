#!/usr/bin/env bash
# One-command setup + test run. Safe to re-run.
# Usage (from inside the launchpad-contracts folder):  bash setup.sh

export PATH="$PATH:$HOME/.foundry/bin"

echo "===== Step 1/4: Foundry ====="
if ! command -v forge >/dev/null 2>&1; then
  echo "Installing Foundry (takes a minute or two)..."
  curl -L https://foundry.paradigm.xyz | bash
  export PATH="$PATH:$HOME/.foundry/bin"
  foundryup
fi
forge --version || { echo "Foundry install failed - copy this message to Claude."; exit 1; }

echo "===== Step 2/4: test library ====="
if [ ! -d lib/forge-std ]; then
  mkdir -p lib
  git clone --depth 1 https://github.com/foundry-rs/forge-std lib/forge-std || { echo "Could not download forge-std."; exit 1; }
  rm -rf lib/forge-std/.git
fi

echo "===== Step 3/4: compiling ====="
if ! forge build > build-output.txt 2>&1; then
  echo
  echo "COMPILE FAILED. First 70 lines of errors (screenshot this):"
  echo "------------------------------------------------------------"
  head -n 70 build-output.txt
  echo "------------------------------------------------------------"
  echo "(Full output saved in build-output.txt)"
  exit 1
fi
echo "Compiled OK."

echo "===== Step 4/4: running tests ====="
forge test > test-output.txt 2>&1
echo
echo "RESULT (last 60 lines - screenshot this):"
echo "------------------------------------------------------------"
tail -n 60 test-output.txt
echo "------------------------------------------------------------"
echo "(Full output saved in test-output.txt)"
