# Launchpad contracts (Foundry project)
Run `bash setup.sh` from this folder. It installs Foundry if needed, downloads the
test library, compiles, and runs every test. UNAUDITED - testnet use only.
